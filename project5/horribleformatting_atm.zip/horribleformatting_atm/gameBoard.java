import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Scanner;
import java.io.*;
import java.awt.event.ActionListener;

import java.util.Random;
import java.lang.Math;

public class gameBoard extends JPanel implements ActionListener
{
  //private Tile buttons[][];
  public static JLabel buttons[][];
  public static boolean buttonFilled[][];   //keep track of which spots in the grid are filled with shapes
  private Container container;
  private GridLayout grid;
  private int linesCleared;
  /***************************************Button Icons************************************/
  public static Icon black = new ImageIcon( "bricks/blacksquare.jpg" );
  public Icon blue = new ImageIcon( "bricks/bluesquare.jpg" );
  public Icon cyan = new ImageIcon( "bricks/cyansquare.jpg" );
  public Icon green = new ImageIcon( "bricks/greensquare.jpg" );
  public Icon magenta = new ImageIcon( "bricks/magentasquare.jpg" );
  public Icon white = new ImageIcon( "bricks/whitesquare.jpg" );
  public Icon red = new ImageIcon( "bricks/redsquare.jpg" );
  public Icon orange = new ImageIcon( "bricks/orangesquare.jpg" );
  public Icon yellow = new ImageIcon( "bricks/yellowsquare.jpg" );
  public Icon gray = new ImageIcon( "bricks/graysquare.jpg" );
  /***************************************************************************************/
  public int scoreFlag;
  public int secondsElapsed;
  public int gameCompletedFlag;
  
  public static boolean gameStarted;
  public static boolean gamePause;
  public static boolean isFalling;
  
 // public static box shape = new box();
  public static JLabel[][] curBlock;
  /***********************************Game Grid Constructor********************************/
  public gameBoard()
  {
    setFocusable(true);
    
    this.setBackground(Color.WHITE);
    this.setPreferredSize(new Dimension(200,400));
    grid = new GridLayout(20,20,0,0);
    this.setLayout(grid);
    
    //buttons = new Tile[10][20];
    buttons = new JLabel[10][20];
    
    this.linesCleared = 0;
    scoreFlag = 0;
    secondsElapsed = 0;
    gameCompletedFlag = 0;
    
    for(int i = 0; i < 10; ++i)
    {
      for(int j = 0; j < 20; ++j)
      {          
        buttons[i][j] = new JLabel();
       // buttonFilled[i][j] = false;    //no boxes are filled
        this.add(buttons[i][j]);
      }
    }
    
    addKeyListener(new TAdapter());
    
    start();
  }
 
  
  /* public static void makeShape()
   {
  for(int i = 0; i < 2; i++)
    {
      for(int j = 0; j < 2; j++)
    {
        if(buttonFilled[i][j] == true)
        {
          return;
        }
        buttons[i][j].setIcon(black);
        buttons[i][j].setSize(30,30);
    }
    }
  System.out.println("Added square");
   //repaint();
   }*/
  
  public static void makeNewBox()
  {
    buttons[0][4].setIcon(black);
    buttons[1][4].setIcon(black);
    buttons[0][5].setIcon(black);
    buttons[1][5].setIcon(black); 
  }
 
  
    //pick a random shape to drop
  public static void dropRandShape()
  {
    Random r = new Random();
    int shapeVal = Math.abs(r.nextInt()) % 7 + 1;
    //call function accordingly
    switch(shapeVal)
    {
      case 1:
        //make a box
        System.out.println("1");  
        makeNewBox();
        isFalling = true;
        break;
        
      case 2:
        System.out.println("2");
        break;
        
      case 3:
        System.out.println("3");
        break;
        
      case 4:
        System.out.println("4");
        break;
        
      case 5:
        System.out.println("5");
        break;
        
      case 6:
        System.out.println("6");
        break;
        
      case 7:
        System.out.println("7");
        break;
    }

  }
  

  public static void start()
  {
    isFalling = false;
    //choose a random shape to drop
    while(!isFalling)
      dropRandShape();
  }
  
  
  class TAdapter extends KeyAdapter {
         public void keyPressed(KeyEvent e) {

            // if (!gameStarted || curPiece.getShape() == Tetrominoes.NoShape) {  
           //      return;
           //  }

             int keycode = e.getKeyCode();

             //user pressed p
             if (keycode == 'p' || keycode == 'P') 
             {
               gamePause = true;
               //pause();
                 return;
             }

             //dont do anything if game is paused
             if (gamePause)
                 return;

             switch (keycode) {
             case KeyEvent.VK_LEFT:
               System.out.println("Move Left");
                 //tryMove(curPiece, curX - 1, curY);
                 break;
             case KeyEvent.VK_RIGHT:
               System.out.println("Move Right");
                // tryMove(curPiece, curX + 1, curY);
                 break;
             case KeyEvent.VK_DOWN:
               System.out.println("Move DOWN");
                 //tryMove(curPiece.rotateRight(), curX, curY);
                 break;
             case KeyEvent.VK_UP:
               System.out.println("Move UP");
                // tryMove(curPiece.rotateLeft(), curX, curY);
                 break;
             case KeyEvent.VK_SPACE:
               System.out.println("Move SPACE");
                 //dropDown();
                 break;
             case 'd':
                 //oneLineDown();
                 break;
             case 'D':
                 //oneLineDown();
                 break;
             }

         }
     }
  /***************************************************************************************/
  
  /***************************************************************************************/
  
  /**************************************Tetris Tile Class**********************************
  private class Tile extends JButton 
  {
    //x and y positions
    private int row;
    private int col;
    //filled or unfilled
    private Icon icon;
    //if true, then tetromino at tile
    private boolean tileStatus;
    
    public Tile(int r, int c, Icon i)
    {
      super("", i);
      this.row = r;
      this.col = c;
      this.tileStatus = false;
    }
    
    //toggle whether there is a tetromino piece at said tile or not
    public void toggleTile(boolean state)
    {
      this.tileStatus = state;
    } 
    
    public boolean isTetromino()
    {
      return this.tileStatus;
    }  
    
    public int getRow()
    {
      return this.row;
    }  
    public int getCol()
    {
      return this.col;
    }  
    
  }
  /***************************************************************************************/
  
  
  public void actionPerformed(ActionEvent e) 
  {
        
   }

}