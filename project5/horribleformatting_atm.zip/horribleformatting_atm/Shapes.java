public interface Shapes 
{
  void makeshape();
 // void rotateLeft();
  //void rotateRight();
 // void drop();
  //void setColor();
}

