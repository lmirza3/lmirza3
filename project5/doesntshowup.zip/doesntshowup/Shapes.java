import java.util.Random;
import java.lang.Math;


public class Shapes 
{
  //each shape will have max 4 coordinates
    int rowsMax = 4;
    int colsMax = 2;

    enum Tetrominoes { Blank, Square, Line, T, Z, S, L, MirrorL};

    private Tetrominoes curShape;
    private int coords[][];
    private int[][][] coordAll;


    public Shapes() 
    {

        coords = new int[rowsMax][colsMax];
        //initialize with all blank originally
        makeShape(Tetrominoes.Blank);

    }

    //initialize the shapes with their perspective coordinates & fill in our final coordinate table
    public void makeShape(Tetrominoes shape) 
    {
         coordAll = new int[][][] {
           {{ 0, 0 },   { 0, 0 },   { 0, 0 },   { 0, 0 }},
           {{ 0, 0 },   { 1, 0 },   { 0, 1 },   { 1, 1 }},
           {{ 0, -1 },  { 0, 0 },   { 0, 1 },   { 0, 2 }},
           {{ -1, 0 },  { 0, 0 },   { 1, 0 },   { 0, 1 }},
           {{ 0, -1 },  { 0, 0 },   { -1, 0 },  { -1, 1 }},
           {{ 0, -1 },  { 0, 0 },   { 1, 0 },   { 1, 1 }},
           {{ -1, -1 }, { 0, -1 },  { 0, 0 },   { 0, 1 }},
           {{ 1, -1 },  { 0, -1 },  { 0, 0 },   { 0, 1 }} };

         
         int makeShape = 0;
        for (int i = 0; i < rowsMax ; i++) 
        {
            for (int j = 0; j < colsMax; ++j) 
            {
                coords[i][j] = coordAll[makeShape][i][j];   //each shape has 4 coordinates
            }
            makeShape++;   //next shape 
        }
        curShape = shape;
    }

    //set new coordinates for y position
    private void makeNewX(int ind, int x) 
    { 
      coords[ind][0] = x; 
    }
    
    //set new coordinates for y position
    private void makeNewY(int ind, int y) 
    { 
      coords[ind][1] = y; 
    }
    
    //get x position from coordinate table
    public int getx(int ind) 
    { 
      return coords[ind][0]; 
    }
    
    //get y position from coordinate table
    public int gety(int ind) 
    { 
      return coords[ind][1]; 
    }
    
    // return the current shape we are using
    public Tetrominoes newShape()  
    { 
      return curShape; 
    }

    public Shapes rotateLeft() 
    {
      //dont need to rotate the square
        if (curShape == Tetrominoes.Square)
            return this;

        Shapes rotated = new Shapes();
        rotated.curShape = curShape;

        for (int i = 0; i < 4; ++i) 
        {
            rotated.makeNewX(i, gety(i));
            rotated.makeNewY(i, -(getx(i)));
        }
        return rotated;
    }

    public Shapes rotateRight()
    {
      //dont need to rotate the square
        if (curShape == Tetrominoes.Square)
            return this;

        Shapes rotated = new Shapes();
        rotated.curShape = curShape;

        for (int i = 0; i < 4; ++i) 
        {
            rotated.makeNewX(i, -(gety(i)));
            rotated.makeNewY(i, getx(i));
        }
        return rotated;
    }
    
       //find the highest x coordinate with curr shape
    public int minx()
    {
      int highestx = coords[0][0];
      int min = highestx;
      for (int i=0; i < 4; i++) 
      {
        if(min > coords[i][0])   //if curr coordnate is smaller than original
        {
          min = coords[i][0];
        }
      }
      return min;
    }

    //find the highest y coordinate with curr shape
    public int minY() 
    {
      int highesty = coords[0][1];
      int min = highesty;
      for (int i=0; i < 4; i++) 
      {
        if(min > coords[i][1])
          min = coords[i][1];
      }
      return min;
    }
    
       public void getRandShape()
    {
        Random randomGenerator = new Random();
        int shapeVal = Math.abs(randomGenerator.nextInt()) % 7 + 1; 
        Tetrominoes[] val = Tetrominoes.values(); 
        
        //pick a random enum value to pick random shape
        makeShape(val[shapeVal]);
        System.out.println("Added a new piece " + val[shapeVal]);
    }

}