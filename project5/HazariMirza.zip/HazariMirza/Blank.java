public class Blank extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new Blank piece");
    }
  
  public Shapes rotateLeft() 
  {
    return this;
  }
  
  public Shapes rotateRight() 
  {
    return this;
  }
}