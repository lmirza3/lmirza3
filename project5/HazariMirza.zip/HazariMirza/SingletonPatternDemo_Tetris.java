public class SingletonPatternDemo_Tetris {
   public static void main(String[] args) 
   {
      //Call Tetris object 
      Tetris object = Tetris.getInstance();
   }
}