public class Line extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new Line piece!");
    }
}