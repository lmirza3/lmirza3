public class L extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new L-Shape piece!");
    }
}