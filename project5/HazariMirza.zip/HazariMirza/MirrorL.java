public class MirrorL extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new Mirrored-L piece!");
    }
}