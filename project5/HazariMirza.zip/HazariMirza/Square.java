public class Square extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new Square piece!");
    }
  
  public Shapes rotateLeft() 
  {
    return this;
  }
  
  public Shapes rotateRight() 
  {
    return this;
  }
}