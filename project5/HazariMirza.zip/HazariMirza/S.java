public class S extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new S-Shape piece!");
    }
}