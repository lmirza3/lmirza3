public class Z extends Shapes
{
   public void displayShape()
    {
      System.out.println("Added a new Z-Shape piece!");
    }
}