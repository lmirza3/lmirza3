/*********************RUNNING THE PROGRAM************/

To run the program, run the file SingletonPatternDemo_Tetris.java
If in terminal/command line: 
1) javac SingletonPatternDemo_Tetris.java
2) java SingletonPatternDemo_Tetris

——————————————————————————————————————————————————————————————

/*********************DESIGN PATTERNS************/

1) Singleton Design Pattern:

The singleton design pattern is one where we only allow 1
instantiation of an object to be called. We do this by making
the constructor of an object private, so no other file can 
access it. Then in another file, we call this object. 

—————————————————————————
-Implementation of Singleton Design Pattern:
In the “Tetris.java” file:

//Private Constructor:
private Tetris()
{
   . . . . 
}

//Function to allow this instance to be called:
   public static Tetris getInstance()
   {
     instance =  new Tetris();
     System.out.println("Tetris used a singleton design pattern.");
     instance.setVisible(true);
      return instance;
   }


In the “SingletonPatternDemo.java” file: 

//Only able to call this object once & in this file:
public static void main(String[] args) 
   {
      //Call Tetris object 
      Tetris object = Tetris.getInstance();
   }

——————————————————————————————————————————————————————————————
2) Factory Design Pattern:






